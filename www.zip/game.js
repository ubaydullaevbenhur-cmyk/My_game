const canvas = document.getElementById('scene');
const ctx = canvas.getContext('2d');

const bg = new Image();
bg.src = 'img/img_bg.png';

const hero = new Image();
hero.src = 'img/img_hero.png';

const coinImg = new Image();
coinImg.src = 'img/coin.png';

const bombImg = new Image();
bombImg.src = 'img/bomb.png';

const heartImg = new Image();
heartImg.src = 'img/heart.png';

let items = [];
let spawnTimer = 0;

let heroX = 100;
let heroY = 200;
let heroW = 50;
let heroH = 90;

let score = 0;
let hp = 3;

let isPlaying = false;
let isPaused = false;
let diffSpeed = 1;
let previousMenu = null;

const diffNames = {
    '0.6': 'Лёгкий',
    '1': 'Средний',
    '1.7': 'Сложный'
};

function getStats(diffKey) {
    return {
        best: parseInt(localStorage.getItem(`bestScore_${diffKey}`)) || 0,
        games: parseInt(localStorage.getItem(`gamesPlayed_${diffKey}`)) || 0
    };
}

function saveStats(diffKey, currentScore) {
    let stats = getStats(diffKey);
    stats.games += 1;
    if (currentScore > stats.best) {
        stats.best = currentScore;
    }
    localStorage.setItem(`bestScore_${diffKey}`, stats.best);
    localStorage.setItem(`gamesPlayed_${diffKey}`, stats.games);
    return stats;
}

const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

const musicGain = audioCtx.createGain();
musicGain.gain.value = 0.5;
musicGain.connect(audioCtx.destination);

const sfxGain = audioCtx.createGain();
sfxGain.gain.value = 0.8;
sfxGain.connect(audioCtx.destination);

const bgMusic = new Audio('sound/music.mp3');
bgMusic.loop = true;
const musicTrack = audioCtx.createMediaElementSource(bgMusic);
musicTrack.connect(musicGain);

const sfxCoin = new Audio('sound/coin.mp3');
audioCtx.createMediaElementSource(sfxCoin).connect(sfxGain);

const sfxBomb = new Audio('sound/bomb.mp3');
audioCtx.createMediaElementSource(sfxBomb).connect(sfxGain);

const sfxHeart = new Audio('sound/heart.mp3');
audioCtx.createMediaElementSource(sfxHeart).connect(sfxGain);

let musicEnabled = true;
let sfxEnabled = true;

function playSound(sound) {
    if (!sfxEnabled) return;
    if (audioCtx.state === 'suspended') audioCtx.resume();
    sound.currentTime = 0;
    sound.play().catch(() => {});
}

const scoreEl = document.getElementById('score');
const hpEl = document.getElementById('hp');
const btnLeft = document.getElementById('btnLeft');
const btnRight = document.getElementById('btnRight');

let moveLeft = false;
let moveRight = false;
let speed = 6;

btnLeft.addEventListener('touchstart', (e) => { e.preventDefault(); moveLeft = true; });
btnLeft.addEventListener('touchend', () => { moveLeft = false; });

btnRight.addEventListener('touchstart', (e) => { e.preventDefault(); moveRight = true; });
btnRight.addEventListener('touchend', () => { moveRight = false; });

function spawnItem() {
    let rand = Math.random() * 100;
    let type = 'coin';
    if (rand > 95) {
        type = 'heart';
    } else if (rand > 65) {
        type = 'bomb';
    }

    items.push({
        x: Math.random() * (canvas.width - 30),
        y: -30,
        w: 30,
        h: 30,
        speed: (2.5 + Math.random() * 2) * diffSpeed,
        type: type
    });
}
function updateItems() {
    spawnTimer++;
    if (spawnTimer > 50) {
        spawnItem();
        spawnTimer = 0;
    }

    for (let i = items.length - 1; i >= 0; i--) {
        let item = items[i];
        item.y += item.speed;

        if (heroX < item.x + item.w &&
            heroX + heroW > item.x &&
            heroY < item.y + item.h &&
            heroY + heroH > item.y) {
            
            if (item.type === 'coin') {
                playSound(sfxCoin);
                score += 1;
                scoreEl.innerText = score;
            }
            
            if (item.type === 'bomb') {
                playSound(sfxBomb);
                hp -= 1;
                hpEl.innerText = hp;
                
                if (hp <= 0) {
                    const diffKey = String(diffSpeed);
                    const updatedStats = saveStats(diffKey, score);
                    
                    document.getElementById('goDiffName').innerText = diffNames[diffKey];
                    document.getElementById('finalScore').innerText = score;
                    document.getElementById('goBestScore').innerText = updatedStats.best;
                    
                    isPlaying = false;
                    bgMusic.pause();
                    bgMusic.currentTime = 0;
                    items = [];
                    gameOverMenu.style.display = 'flex';
                    break;
                }
            }
            
            if (item.type === 'heart') {
                playSound(sfxHeart);
                hp = 3;
                hpEl.innerText = hp;
            }

            items.splice(i, 1);
            continue;
        }

        if (item.y > canvas.height) {
            items.splice(i, 1);
        }
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);
    ctx.drawImage(hero, heroX, heroY, heroW, heroH);

    for (let i = 0; i < items.length; i++) {
        let item = items[i];
        let img = coinImg;
        if (item.type === 'bomb') img = bombImg;
        if (item.type === 'heart') img = heartImg;
        ctx.drawImage(img, item.x, item.y, item.w, item.h);
    }
}

function loop() {
    if (isPlaying && !isPaused) {
        if (moveLeft && heroX > 0) heroX -= speed;
        if (moveRight && heroX < canvas.width - heroW) heroX += speed;
        updateItems();
    }
    draw();
    requestAnimationFrame(loop);
}

loop();

const mainMenu = document.getElementById('mainMenu');
const pauseMenu = document.getElementById('pauseMenu');
const settingsMenu = document.getElementById('settingsMenu');
const statsMenu = document.getElementById('statsMenu');
const gameOverMenu = document.getElementById('gameOverMenu');
const exitMenu = document.getElementById('exitMenu');

function startNewGame() {
    mainMenu.style.display = 'none';
    gameOverMenu.style.display = 'none';
    score = 0;
    hp = 3;
    items = [];
    scoreEl.innerText = score;
    hpEl.innerText = hp;
    isPlaying = true;
    isPaused = false;
    if (audioCtx.state === 'suspended') audioCtx.resume();
    if (musicEnabled) bgMusic.play().catch(() => {});
}

document.getElementById('btnPlay').addEventListener('click', startNewGame);
document.getElementById('btnRestart').addEventListener('click', startNewGame);

document.getElementById('btnPause').addEventListener('click', () => {
    if (!isPlaying) return;
    isPaused = true;
    pauseMenu.style.display = 'flex';
    bgMusic.pause();
});

document.getElementById('btnResume').addEventListener('click', () => {
    isPaused = false;
    pauseMenu.style.display = 'none';
    if (audioCtx.state === 'suspended') audioCtx.resume();
    if (musicEnabled) bgMusic.play().catch(() => {});
});

document.getElementById('btnSettings').addEventListener('click', () => {
    previousMenu = mainMenu;
    mainMenu.style.display = 'none';
    settingsMenu.style.display = 'flex';
});

document.getElementById('btnPauseSettings').addEventListener('click', () => {
    previousMenu = pauseMenu;
    pauseMenu.style.display = 'none';
    settingsMenu.style.display = 'flex';
});

document.getElementById('btnBackSettings').addEventListener('click', () => {
    settingsMenu.style.display = 'none';
    if (previousMenu) {
        previousMenu.style.display = 'flex';
    } else {
        mainMenu.style.display = 'flex';
    }
});

document.getElementById('btnToMain').addEventListener('click', () => {
    isPlaying = false;
    isPaused = false;
    pauseMenu.style.display = 'none';
    mainMenu.style.display = 'flex';
    bgMusic.pause();
    bgMusic.currentTime = 0;
});

document.getElementById('btnGameOverToMain').addEventListener('click', () => {
    gameOverMenu.style.display = 'none';
    mainMenu.style.display = 'flex';
});

function updateStatsDisplay(diffKey) {
    const stats = getStats(diffKey);
    document.getElementById('bestScore').innerText = stats.best;
    document.getElementById('gamesPlayed').innerText = stats.games;
}

document.getElementById('btnStats').addEventListener('click', () => {
    const currentDiffKey = String(diffSpeed);
    document.getElementById('statsDiffSelect').value = currentDiffKey;
    updateStatsDisplay(currentDiffKey);
    mainMenu.style.display = 'none';
    statsMenu.style.display = 'flex';
});

document.getElementById('statsDiffSelect').addEventListener('change', (e) => {
    updateStatsDisplay(e.target.value);
});

document.getElementById('btnBackStats').addEventListener('click', () => {
    statsMenu.style.display = 'none';
    mainMenu.style.display = 'flex';
});

document.getElementById('btnExit').addEventListener('click', () => {
    // 1. Стандартная команда для HTML to APK Builder
    if (typeof Android !== 'undefined' && typeof Android.exitApp === 'function') {
        Android.exitApp();
    } 
    // 2. Альтернативный вариант для некоторых версий этого конструктора
    else if (typeof HTML2APK !== 'undefined' && typeof HTML2APK.exitApp === 'function') {
        HTML2APK.exitApp();
    }
    // 3. Метод для Cordova / PhoneGap
    else if (navigator.app && navigator.app.exitApp) {
        navigator.app.exitApp();
    } 
    // 4. Запасной вариант (если запущено в обычном браузере)
    else {
        window.close();
        mainMenu.style.display = 'none';
        exitMenu.style.display = 'flex';
    }
});

document.getElementById('btnCancelExit').addEventListener('click', () => {
    exitMenu.style.display = 'none';
    mainMenu.style.display = 'flex';
});

document.getElementById('chkMusic').addEventListener('change', (e) => {
    musicEnabled = e.target.checked;
    musicGain.gain.value = musicEnabled ? parseFloat(document.getElementById('volMusic').value) : 0;
});

document.getElementById('volMusic').addEventListener('input', (e) => {
    if (musicEnabled) musicGain.gain.value = parseFloat(e.target.value);
});

document.getElementById('chkSfx').addEventListener('change', (e) => {
    sfxEnabled = e.target.checked;
    sfxGain.gain.value = sfxEnabled ? parseFloat(document.getElementById('volSfx').value) : 0;
});

document.getElementById('volSfx').addEventListener('input', (e) => {
    if (sfxEnabled) sfxGain.gain.value = parseFloat(e.target.value);
});

document.getElementById('selectDiff').addEventListener('change', (e) => {
    diffSpeed = parseFloat(e.target.value);
});
